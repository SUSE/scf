# Display HPE Helion Stackato environment

A simple Go application to display the Stackato environment of the
instance the app is running on.

# Deploy to HPE Helion Stackato

    stackato push -n

# Requirements

This application requires Stackato 2.8 or the later.
